import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GUI {
	GameData gameData;
	GameControl gameControl;  // 添加 GameControl 引用
	JFrame f;
	JLabel[][] b;

	// 构造器中接收 GameControl 对象
	GUI(GameData gameData, GameControl gameControl) {
		this.gameData = gameData;
		this.gameControl = gameControl;  // 初始化 gameControl
		f = new JFrame("Magic Tower");
		b = new JLabel[gameData.H][gameData.W];

		for (int i = 0; i < gameData.H; i++) {
			for (int j = 0; j < gameData.W; j++) {
				b[i][j] = new JLabel();
				b[i][j].setBounds(j * 100, i * 100, 100, 100);
				f.add(b[i][j]);

				// 为每个格子添加鼠标监听器
				final int x = i; // 行坐标
				final int y = j; // 列坐标
				b[i][j].addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						handleMouseClick(x, y);
					}
				});
			}
		}

		f.setSize(gameData.H * 100 + 10, gameData.W * 100 + 40);
		f.setLayout(null);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		refreshGUI();
	}

	public void refreshGUI() {
		for (int i = 0; i < gameData.H; i++) {
			for (int j = 0; j < gameData.W; j++) {
				Image scaledImage = chooseImage(gameData.map[gameData.currentLevel][i][j]);
				b[i][j].setIcon(new ImageIcon(scaledImage));
			}
		}
	}

	// 选择并加载图片
	private static Image chooseImage(int index) {
		// 将图片路径设置为相对路径的 images 目录
		String basePath = "Magic_Tower_V0.2/";

		ImageIcon[] icons = new ImageIcon[10];
		icons[0] = new ImageIcon(basePath + "Wall.jpg");
		icons[1] = new ImageIcon(basePath + "Floor.jpg");
		icons[2] = new ImageIcon(basePath + "Key.jpg");
		icons[3] = new ImageIcon(basePath + "Door.jpg");
		icons[4] = new ImageIcon(basePath + "Stair.jpg");
		icons[5] = new ImageIcon(basePath + "Exit.jpg");
		icons[6] = new ImageIcon(basePath + "Hero.jpg");
		icons[7] = new ImageIcon(basePath + "Potion.jpg");
		icons[8] = new ImageIcon(basePath + "Monster.jpg");

		ImageIcon icon;
		if (index > 10) {
			icon = icons[7];
		} else if (index < 0) {
			icon = icons[8];
		} else {
			icon = icons[index];
		}

		// 如果图片未找到，输出警告
		if (icon.getImageLoadStatus() != java.awt.MediaTracker.COMPLETE) {
			System.out.println("Warning: image not found for index: " + index);
		}

		return icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	}


	// setter 方法，用于设置 gameControl
	public void setGameControl(GameControl gameControl) {
		this.gameControl = gameControl;
	}

	// 处理鼠标点击事件
	private void handleMouseClick(int x, int y) {
		int pX = gameData.pX; // 当前玩家的X坐标
		int pY = gameData.pY; // 当前玩家的Y坐标

		// 判断点击的格子是否是相邻格子（上下左右）
		if ((Math.abs(pX - x) == 1 && pY == y) || (Math.abs(pY - y) == 1 && pX == x)) {
			// 相邻格子，调用移动方法
			gameControl.handleInputByMouse(x, y);  // 使用 gameControl 的方法
			gameData.printMap();
			refreshGUI();
		} else {
			System.out.println("You can only move to adjacent tiles!");
		}
	}
}
