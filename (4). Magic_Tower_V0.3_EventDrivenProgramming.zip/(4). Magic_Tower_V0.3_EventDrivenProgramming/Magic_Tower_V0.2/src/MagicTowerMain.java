public class MagicTowerMain {
	static GameData gameData;
	static GameControl gameControl;
	static Menu menu;
	static GUI gui;

	public static void main(String[] args) {
		System.out.println(System.getProperty("user.dir"));

		// 使用相对路径
		String basePath = "Magic_Tower_V0.2/";

		// 初始化游戏数据
		gameData = new GameData();
		gameData.readMapFromFile(basePath + "Map.in");
		gameData.printMap();

		// 先初始化 GUI，gameControl 先设为 null
		gui = new GUI(gameData, null);  // 临时传入 null

		// 初始化菜单
		menu = new Menu(gameData);
		menu.loadMenu(basePath + "Menu.XML");

		// 初始化 GameControl 对象，并传递给 GUI
		gameControl = new GameControl(gameData, menu, gui);

		// 设置 GUI 的 gameControl
		gui.setGameControl(gameControl);  // 通过 setter 方法传递 gameControl 对象

		// 开始游戏
		gameControl.gameStart();
	}
}
